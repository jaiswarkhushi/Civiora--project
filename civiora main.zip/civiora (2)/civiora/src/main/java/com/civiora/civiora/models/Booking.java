package com.civiora.civiora.models;

import jakarta.persistence.*;

@Entity
@Table(name = "bookings")
public class Booking {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String name;     // Resident name

    @Column(nullable = false)
    private String venue;    // clubhouse | party-hall | terrace

    @Column(nullable = false)
    private String date;     // e.g. "2026-03-20"

    @Column(nullable = false)
    private String slot;     // e.g. "6PM–10PM"

    @Column(nullable = false)
    private String purpose;

    @Column(nullable = false)
    private String status;   // pending | confirmed | cancelled

    // ── Constructors ──────────────────────────────────────────────────────────
    public Booking() {}

    // ── Getters ───────────────────────────────────────────────────────────────
    public Long   getId()      { return id; }
    public String getName()    { return name; }
    public String getVenue()   { return venue; }
    public String getDate()    { return date; }
    public String getSlot()    { return slot; }
    public String getPurpose() { return purpose; }
    public String getStatus()  { return status; }

    // ── Setters ───────────────────────────────────────────────────────────────
    public void setId(Long id)           { this.id      = id; }
    public void setName(String name)     { this.name    = name; }
    public void setVenue(String venue)   { this.venue   = venue; }
    public void setDate(String date)     { this.date    = date; }
    public void setSlot(String slot)     { this.slot    = slot; }
    public void setPurpose(String p)     { this.purpose = p; }
    public void setStatus(String status) { this.status  = status; }
}