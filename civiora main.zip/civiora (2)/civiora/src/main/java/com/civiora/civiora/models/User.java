package com.civiora.civiora.models;

import jakarta.persistence.*;

@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false, unique = true)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private String wing;

    @Column(nullable = false)
    private String flat;

    @Column(nullable = false)
    private String role;

    @Column(nullable = false)
    private double balance = 0.0;

    // ── Constructors ──────────────────────────────────────────────────────────
    public User() {}

    public User(int id, String name, String email, String password,
                String wing, String flat, String role, double balance) {
        this.id       = id;
        this.name     = name;
        this.email    = email;
        this.password = password;
        this.wing     = wing;
        this.flat     = flat;
        this.role     = role;
        this.balance  = balance;
    }

    // ── Getters ───────────────────────────────────────────────────────────────
    public int    getId()       { return id; }
    public String getName()     { return name; }
    public String getEmail()    { return email; }
    public String getPassword() { return password; }
    public String getWing()     { return wing; }
    public String getFlat()     { return flat; }
    public String getRole()     { return role; }
    public double getBalance()  { return balance; }

    // ── Setters ───────────────────────────────────────────────────────────────
    public void setId(int id)             { this.id       = id; }
    public void setName(String name)      { this.name     = name; }
    public void setEmail(String email)    { this.email    = email; }
    public void setPassword(String pass)  { this.password = pass; }
    public void setWing(String wing)      { this.wing     = wing; }
    public void setFlat(String flat)      { this.flat     = flat; }
    public void setRole(String role)      { this.role     = role; }
    public void setBalance(double bal)    { this.balance  = bal; }
}