package com.civiora.civiora.repositories;

import com.civiora.civiora.models.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface PaymentRepo extends JpaRepository<Payment, Long> {
    List<Payment> findByStatusNot(String status);
}