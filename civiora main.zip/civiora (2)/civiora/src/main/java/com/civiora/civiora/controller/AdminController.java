package com.civiora.civiora.controller;

import com.civiora.civiora.models.*;
import com.civiora.civiora.repositories.*;
import com.civiora.civiora.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/admin")
@CrossOrigin(origins = "*")
public class AdminController {

    @Autowired UserRepo       userRepo;
    @Autowired NoticeRepo     noticeRepo;
    @Autowired PaymentRepo    paymentRepo;
    @Autowired BookingRepo    bookingRepo;
    @Autowired ActivityLogRepo logRepo;
    @Autowired EmailService   emailService;

    // ── USERS ──────────────────────────────────────────────────────────────────

    @GetMapping("/users")
    public List<User> getAllUsers() {
        return userRepo.findAll();
    }

    @PostMapping("/users")
    public ResponseEntity<String> addUser(@RequestBody User user) {
        userRepo.save(user);
        logRepo.save(new ActivityLog("Created user " + user.getName(), "Admin"));
        return ResponseEntity.ok("User added successfully");
    }

    @DeleteMapping("/users/{id}")
    public ResponseEntity<String> deleteUser(@PathVariable int id) {
        User user = userRepo.findById(id).orElse(null);
        if (user == null) return ResponseEntity.notFound().build();
        userRepo.deleteById(id);
        logRepo.save(new ActivityLog("Deleted user " + user.getName(), "Admin"));
        return ResponseEntity.ok("User deleted");
    }

    // ── NOTICES ────────────────────────────────────────────────────────────────

    @GetMapping("/notices")
    public List<Notice> getAllNotices() {
        return noticeRepo.findAllByOrderByDateDesc();
    }

    @PostMapping("/notices")
    public ResponseEntity<String> addNotice(@RequestBody Notice notice) {
        notice.setDate(LocalDateTime.now());
        notice.setAuthor("Admin");
        noticeRepo.save(notice);
        logRepo.save(new ActivityLog("Posted notice: " + notice.getTitle(), "Admin"));
        return ResponseEntity.ok("Notice posted successfully");
    }

    @DeleteMapping("/notices/{id}")
    public ResponseEntity<String> deleteNotice(@PathVariable Long id) {
        Notice n = noticeRepo.findById(id).orElse(null);
        if (n == null) return ResponseEntity.notFound().build();
        noticeRepo.deleteById(id);
        logRepo.save(new ActivityLog("Deleted notice: " + n.getTitle(), "Admin"));
        return ResponseEntity.ok("Notice deleted");
    }

    // ── PAYMENTS ───────────────────────────────────────────────────────────────

    @GetMapping("/payments")
    public List<Payment> getAllPayments() {
        return paymentRepo.findAll();
    }

    @PostMapping("/payments")
    public ResponseEntity<String> addPayment(@RequestBody Payment payment) {
        paymentRepo.save(payment);
        logRepo.save(new ActivityLog("Added payment record for " + payment.getName(), "Admin"));
        return ResponseEntity.ok("Payment record saved");
    }

    @PatchMapping("/payments/{id}/mark-paid")
    public ResponseEntity<String> markPaid(@PathVariable Long id) {
        Payment p = paymentRepo.findById(id).orElse(null);
        if (p == null) return ResponseEntity.notFound().build();
        p.setStatus("paid");
        p.setPaidOn(LocalDateTime.now());
        paymentRepo.save(p);
        logRepo.save(new ActivityLog("Marked " + p.getName() + " payment as Paid", "Admin"));
        return ResponseEntity.ok("Marked as paid");
    }

    @DeleteMapping("/payments/{id}")
    public ResponseEntity<String> deletePayment(@PathVariable Long id) {
        paymentRepo.deleteById(id);
        return ResponseEntity.ok("Payment record deleted");
    }

    @PostMapping("/send-reminders")
    public ResponseEntity<String> sendDueReminders() {
        List<Payment> due = paymentRepo.findByStatusNot("paid");
        for (Payment p : due) {
            userRepo.findByEmail(p.getEmail()).ifPresent(user ->
                emailService.sendPaymentReminder(user.getEmail(), user.getName(), p.getAmount(), p.getMonth())
            );
        }
        logRepo.save(new ActivityLog("Sent due reminders to " + due.size() + " residents", "Admin"));
        return ResponseEntity.ok("Reminders sent to " + due.size() + " residents");
    }

    // ── BOOKINGS ───────────────────────────────────────────────────────────────

    @GetMapping("/bookings")
    public List<Booking> getAllBookings() {
        return bookingRepo.findAll();
    }

    @PatchMapping("/bookings/{id}/approve")
    public ResponseEntity<String> approveBooking(@PathVariable Long id) {
        Booking b = bookingRepo.findById(id).orElse(null);
        if (b == null) return ResponseEntity.notFound().build();
        b.setStatus("confirmed");
        bookingRepo.save(b);
        logRepo.save(new ActivityLog("Approved booking by " + b.getName() + " for " + b.getVenue(), "Admin"));
        return ResponseEntity.ok("Booking approved");
    }

    @PatchMapping("/bookings/{id}/cancel")
    public ResponseEntity<String> cancelBooking(@PathVariable Long id) {
        Booking b = bookingRepo.findById(id).orElse(null);
        if (b == null) return ResponseEntity.notFound().build();
        b.setStatus("cancelled");
        bookingRepo.save(b);
        logRepo.save(new ActivityLog("Cancelled booking by " + b.getName(), "Admin"));
        return ResponseEntity.ok("Booking cancelled");
    }

    // ── ACTIVITY LOG ───────────────────────────────────────────────────────────

    @GetMapping("/logs")
    public List<ActivityLog> getLogs() {
        return logRepo.findAllByOrderByCreatedAtDesc();
    }

    @DeleteMapping("/logs")
    public ResponseEntity<String> clearLogs() {
        logRepo.deleteAll();
        return ResponseEntity.ok("Logs cleared");
    }
}