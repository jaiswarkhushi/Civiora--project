package com.civiora.civiora.repositories;

import com.civiora.civiora.models.Booking;
import org.springframework.data.jpa.repository.JpaRepository;

public interface BookingRepo extends JpaRepository<Booking, Long> { }