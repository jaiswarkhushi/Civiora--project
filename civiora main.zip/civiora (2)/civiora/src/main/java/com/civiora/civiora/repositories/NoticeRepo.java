// ── NoticeRepo.java ───────────────────────────────────────────────────────────
package com.civiora.civiora.repositories;

import com.civiora.civiora.models.Notice;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface NoticeRepo extends JpaRepository<Notice, Long> {
    List<Notice> findAllByOrderByDateDesc();
}