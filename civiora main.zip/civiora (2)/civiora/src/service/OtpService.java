package com.civiora.civiora.service;

import org.springframework.stereotype.Service;
import java.time.LocalDateTime;
import java.util.Map;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;

@Service
public class OtpService {

    // Store: email → [otp, expiry]
    private final Map<String, OtpEntry> otpStore = new ConcurrentHashMap<>();

    private static final int OTP_EXPIRY_MINUTES = 5;

    /** Generate a 6-digit OTP and store it against the email */
    public String generateOtp(String email) {
        String otp = String.format("%06d", new Random().nextInt(999999));
        otpStore.put(email.toLowerCase(), new OtpEntry(otp, LocalDateTime.now().plusMinutes(OTP_EXPIRY_MINUTES)));
        return otp;
    }

    /** Returns true if the OTP matches and is not expired */
    public boolean validateOtp(String email, String otp) {
        OtpEntry entry = otpStore.get(email.toLowerCase());
        if (entry == null) return false;
        if (LocalDateTime.now().isAfter(entry.expiry())) {
            otpStore.remove(email.toLowerCase()); // cleanup expired
            return false;
        }
        boolean valid = entry.otp().equals(otp.trim());
        if (valid) otpStore.remove(email.toLowerCase()); // OTP used, remove it
        return valid;
    }

    private record OtpEntry(String otp, LocalDateTime expiry) {}
}