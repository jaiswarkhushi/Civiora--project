package com.civiora.civiora.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

@Service
public class EmailService {

    @Autowired
    private JavaMailSender mailSender;

    /** OTP email for signup verification */
    public void sendOtpEmail(String toEmail, String otp) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(toEmail);
        message.setSubject("Civiora – Your Email Verification OTP");
        message.setText(
            "Dear Resident,\n\n" +
            "Welcome to Civiora – Society Management System.\n\n" +
            "Your One-Time Password (OTP) for email verification is:\n\n" +
            "        " + otp + "\n\n" +
            "This OTP is valid for 5 minutes. Do not share it with anyone.\n\n" +
            "Regards,\nTeam Civiora"
        );
        mailSender.send(message);
    }

    /** Maintenance due reminder email */
    public void sendPaymentReminder(String toEmail, String name, double amount, String month) {
        SimpleMailMessage message = new SimpleMailMessage();
        message.setTo(toEmail);
        message.setSubject("Civiora – Maintenance Due Reminder");
        message.setText(
            "Dear " + name + ",\n\n" +
            "This is a friendly reminder that your maintenance charges for " + month + " are due.\n\n" +
            "Amount Due: ₹" + amount + "\n\n" +
            "Please pay at your earliest convenience via the Civiora portal (Dashboard → Payment).\n\n" +
            "Late fee of ₹50/day will apply after the due date.\n\n" +
            "Thank you,\nCiviora Society Management"
        );
        mailSender.send(message);
    }
}